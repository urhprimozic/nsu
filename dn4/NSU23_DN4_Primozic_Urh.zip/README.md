Poročilo je v datoteki poročilo_nal1_nal2.pdf.
Rešitvne naloge 1 so v naloga1.ipynb
Algoritem za nalogo 2 je implementiran v ProGEDescend.py (progedescend())
Primerjava klasičnega Progeda z adaptivnim je v nal2_grafi.py.
Primer uporabe ProGEDescend za |S| = 100 je v naloga2.ipynb
